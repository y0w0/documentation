---
sidebar_position: 3
---

# 系统配置

主要介绍一些类似rsetup 这样的命令使能或者禁用某些功能。
