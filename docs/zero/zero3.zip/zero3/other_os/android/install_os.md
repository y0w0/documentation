---
sidebar_position: 2
---

# 系统安装

## 镜像下载

## 系统烧录

## 启动系统
