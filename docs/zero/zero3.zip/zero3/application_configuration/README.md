---
sidebar_position: 4
---

# 应用部署

主要介绍类似 Samba, Docker, PVE, OMV, LAMP, Cheese, 远程控制面板等常见应用的配置及使用
