---
sidebar_position: 2
---

# 系统使用

主要介绍系统如何使用

## 设置用户名和密码

## 设置网络

## 自动登录

## 语言设置

## 远程登录 (串口/VNC/SSH)

## 音视频使用

## 聊天视频使用

## 玩游戏

## 办公OFFICE

## Android In Container
