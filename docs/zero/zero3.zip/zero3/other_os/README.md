---
sidebar_position: 8
---

# 其他系统

非 Yocto 的其他系统，例如 Android
